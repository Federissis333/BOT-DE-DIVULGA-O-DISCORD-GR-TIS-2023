# Mass DM
 Como Ligar ? Depois de ter instalado as dependências, e só utilizar o comando node script, o bot vai ligar normalmente!

Como configurar? Depois de você ter botado o token no arquivo "settings" e escolher a mensagem que você deseja enviar em "mensage" , e também utilizar o comando, basta escolher o modo, modo 1 envia a mensagem de forma padrão (chances do bot cair rápido), modo 2 você pode customizar o tempo de mensagem será enviada de um membro para o outro!

OBS: Recomendo usar um bot "velho" pra divulgar, um bot criado recentemente pode cair nem rápido.

bom uso!
